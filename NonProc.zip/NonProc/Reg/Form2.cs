﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reg
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "рун11DataSet.Владельцы". При необходимости она может быть перемещена или удалена.
            this.владельцыTableAdapter.Fill(this.рун11DataSet.Владельцы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "руна11DataSet.Владельцы". При необходимости она может быть перемещена или удалена.
          ;
            // TODO: данная строка кода позволяет загрузить данные в таблицу "рун11DataSet.Владельцы". При необходимости она может быть перемещена или удалена.
            this.владельцыTableAdapter.Fill(this.рун11DataSet.Владельцы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "павлов_бдDataSet.Владелец". При необходимости она может быть перемещена или удалена.
            

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=руна11.mdb";//строка соеденения
            OleDbConnection dbConnection = new OleDbConnection(connectionString);//создаем соеденение

            //Выполянем запрос к БД
            dbConnection.Open();//открываем соеденение
            string query = "INSERT INTO Владельцы(ФИО,Телефон)";
            OleDbCommand dbCommand = new OleDbCommand(query, dbConnection);//командер
            dbCommand.ExecuteNonQuery();
            dbConnection.Close();
            MessageBox.Show("Данные добавлены");

        }

        private void владельцыBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.владельцыBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.рун11DataSet);

        }
    }
}
