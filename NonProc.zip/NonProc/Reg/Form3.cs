﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reg
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "павлов_бдDataSet.Квартиры". При необходимости она может быть перемещена или удалена.
            this.квартирыTableAdapter.Fill(this.павлов_бдDataSet.Квартиры);

        }

        public int i = 1;
        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = (Bitmap)Properties.Resources.ResourceManager.GetObject("a" + i.ToString());
            i++;
            if (i == 5) i = 1;
        }
    }
}
