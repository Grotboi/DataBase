﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reg
{
    public partial class Form4 : Form
    {
        public object myConnection { get; private set; }
        public object dbConnection { get; private set; }
        public object DataSet { get; private set; }

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "павлов_бдDataSet1.Покупатели". При необходимости она может быть перемещена или удалена.
            this.покупателиTableAdapter.Fill(this.павлов_бдDataSet1.Покупатели);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "базаданных21DataSet.Организация". При необходимости она может быть перемещена или удалена.
            this.организацияTableAdapter.Fill(this.базаданных21DataSet.Организация);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "павлов_бдDataSet.Покупатели". При необходимости она может быть перемещена или удалена.
            this.организацияTableAdapter.Fill(this.базаданных21DataSet.Организация);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = String.Concat("SELECT * FROM Покупатели WHERE Nzach=", textBox1.Text);
            string connectionString;
            connectionString = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                       @"Data Source=|DataDirectory|\\руна11.mdb";

            OleDbConnection connection = new OleDbConnection(connectionString);
            connection.Open();
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\\руна11.mdb");
            con.Open();
            string queryString = "insert into Покупатели (ФИО, Телефон) values('" + textBox1.Text + "','" + textBox2.Text + "')";
            OleDbCommand command = new OleDbCommand(queryString, con);
            command.ExecuteNonQuery();
            con.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\\руна11.mdb");
            con.Open();
            string queryString = "delete FROM Покупатели WHERE Код = 3";
            OleDbCommand command = new OleDbCommand(queryString, con);
            command.ExecuteNonQuery();
            con.Close();


        }
    }
}
