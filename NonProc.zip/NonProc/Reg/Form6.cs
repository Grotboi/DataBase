﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using Word = Microsoft.Office.Interop.Word;

namespace Reg
{
    public partial class Form6 : Form
    {
        public string quer { get; private set; }
        public OleDbConnection myConnection { get; private set; }

        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Word._Application oWord = new Word.Application();
            oWord.Visible = true;
            Word._Document oDoc = oWord.Documents.Open(Environment.CurrentDirectory + "\\dogovor.docx");
            oDoc.Bookmarks["ff1"].Range.Text = textBox1.Text;
            oDoc.Bookmarks["ff2"].Range.Text =  textBox2.Text;
            oDoc.Bookmarks["ff3"].Range.Text = textBox3.Text;
            oDoc.Bookmarks["ff4"].Range.Text = textBox4.Text;
            oDoc.Bookmarks["ff6"].Range.Text = textBox4.Text;

            // добавляем картинку на место закладки (path-Путь к картинке)

            oDoc.SaveAs(FileName: Environment.CurrentDirectory + "\\New.docx");
            oDoc.Close();
            oWord.Quit();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }
    }
}
