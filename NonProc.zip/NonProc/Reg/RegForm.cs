﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Reg
{
    public partial class RegForm : Form
    {
        RegistrationForm registrationForm = new RegistrationForm();

        public RegForm()
        {
            InitializeComponent();

            registrationForm.ShowDialog(); // Отображаем форму авторизации.

            nameLabel.Text = "Вы вошли в систему, " + registrationForm.login + "!";
        }

        private void RegForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AboutBox1 a = new AboutBox1();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
        }
    }
}
